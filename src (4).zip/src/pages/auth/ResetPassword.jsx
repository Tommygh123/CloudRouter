import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-hot-toast';

import AuthCard from '../../components/auth/AuthCard';
import FormField from '../../components/auth/FormField';
import PasswordInput from '../../components/auth/PasswordInput';

import { authService } from '../../services/authService';
import { tenantService } from '../../services/tenantService';
import { supabase } from '../../lib/supabase';

export default function ResetPassword() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    password: '',
    confirm: '',
  });

  const [loading, setLoading] = useState(false);

  async function submit(event) {
    event.preventDefault();

    // ========================================================
    // VALIDATION
    // ========================================================

    if (form.password.length < 8) {
      toast.error(
        'Use at least 8 characters.',
      );
      return;
    }

    if (
      form.password !== form.confirm
    ) {
      toast.error(
        'Passwords do not match.',
      );
      return;
    }

    try {
      setLoading(true);

      // ======================================================
      // 1. UPDATE PASSWORD
      // ======================================================

      const {
        error: passwordError,
      } =
        await authService.updatePassword(
          form.password,
        );

      if (passwordError) {
        throw passwordError;
      }

      // ======================================================
      // 2. GET CURRENT AUTH SESSION
      // ======================================================

      let {
        data: sessionData,
        error: sessionError,
      } =
        await supabase.auth.getSession();

      if (sessionError) {
        throw sessionError;
      }

      /*
       * Normally the password-recovery link has already
       * established a Supabase session.
       *
       * If we do not have one, try refreshing it.
       */
      if (!sessionData?.session) {
        const {
          data: refreshedData,
          error: refreshError,
        } =
          await supabase.auth.refreshSession();

        if (!refreshError) {
          sessionData = refreshedData;
        }
      }

      const user =
        sessionData?.session?.user;

      // ======================================================
      // 3. PASSWORD CHANGED BUT SESSION NOT AVAILABLE
      // ======================================================

      if (!user?.id) {
        toast.success(
          'Password updated. Please sign in.',
        );

        navigate('/login', {
          replace: true,
        });

        return;
      }

      // ======================================================
      // 4. CHECK WORKSPACE MEMBERSHIP
      // ======================================================

      const {
        data: memberships,
        error: membershipError,
      } = await tenantService.getMemberships(
        user.id,
      );

      if (membershipError) {
        console.error(
          'Could not determine workspace after password reset:',
          membershipError,
        );

        /*
         * Do NOT send the user to BusinessSetup when the
         * membership lookup itself failed.
         *
         * Doing that caused an existing Kanwave user to
         * appear as though they were a new customer.
         */
        toast.success(
          'Password updated successfully.',
        );

        toast.error(
          'Your workspace could not be loaded. Please sign in again.',
        );

        await supabase.auth.signOut();

        navigate('/login', {
          replace: true,
        });

        return;
      }

      // ======================================================
      // 5. EXISTING WORKSPACE MEMBER
      // ======================================================

      if (
        Array.isArray(memberships) &&
        memberships.length > 0
      ) {
        const membership =
          memberships[0];

        const businessName =
          membership?.tenants
            ?.business_name;

        toast.success(
          businessName
            ? `Password updated. Welcome back to ${businessName}.`
            : 'Password updated successfully.',
        );

        /*
         * Existing:
         *
         * Owner
         * Admin
         * Cashier
         * Technician
         * etc.
         *
         * all enter the application here.
         *
         * Dashboard/menu authorization can then use
         * membership.roles.code.
         */
        navigate('/dashboard', {
          replace: true,
        });

        return;
      }

      // ======================================================
      // 6. AUTH USER WITH NO ACTIVE TENANT MEMBERSHIP
      // ======================================================

      /*
       * This is the ONLY situation where business onboarding
       * should be considered.
       *
       * Do not use this branch for invited employees while
       * their invitation is still being accepted.
       */
      toast.success(
        'Password updated successfully.',
      );

      navigate(
        '/onboarding/business',
        {
          replace: true,
        },
      );
    } catch (error) {
      console.error(
        'Password reset failed:',
        error,
      );

      toast.error(
        error?.message ||
          'Password could not be updated.',
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthCard
      title="Choose a new password"
      subtitle="Create a strong password for your CloudRouter account."
    >
      <form
        className="space-y-4"
        onSubmit={submit}
      >
        <FormField label="New password">
          <PasswordInput
            name="password"
            value={form.password}
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                password:
                  event.target.value,
              }))
            }
            autoComplete="new-password"
          />
        </FormField>

        <FormField label="Confirm password">
          <PasswordInput
            name="confirm"
            value={form.confirm}
            onChange={(event) =>
              setForm((current) => ({
                ...current,
                confirm:
                  event.target.value,
              }))
            }
            autoComplete="new-password"
          />
        </FormField>

        <button
          type="submit"
          disabled={loading}
          className="w-full rounded-xl bg-indigo-600 px-4 py-3.5 font-semibold text-white transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
        >
          {loading
            ? 'Updating…'
            : 'Update password'}
        </button>
      </form>
    </AuthCard>
  );
}