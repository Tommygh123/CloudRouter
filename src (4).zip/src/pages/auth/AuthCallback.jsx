import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { supabase } from '../../lib/supabase';
import { tenantService } from '../../services/tenantService';

export default function AuthCallback() {
  const navigate = useNavigate();

  const [message, setMessage] = useState(
    'Completing authentication…',
  );

  useEffect(() => {
    let active = true;

    async function completeAuthentication() {
      try {
        // ====================================================
        // 1. GET CURRENT SUPABASE SESSION
        // ====================================================

        const {
          data: sessionData,
          error: sessionError,
        } = await supabase.auth.getSession();

        if (!active) {
          return;
        }

        if (
          sessionError ||
          !sessionData?.session?.user
        ) {
          console.error(
            'Auth callback session unavailable:',
            sessionError,
          );

          navigate(
            '/login',
            {
              replace: true,
            },
          );

          return;
        }

        const user =
          sessionData.session.user;

        // ====================================================
        // 2. CHECK EXISTING CLOUDROUTER MEMBERSHIP
        // ====================================================

        setMessage(
          'Checking your CloudRouter workspace…',
        );

        const {
          data: memberships,
          error: membershipError,
        } =
          await tenantService.getMemberships(
            user.id,
          );

        if (!active) {
          return;
        }

        // ====================================================
        // 3. DO NOT TREAT LOOKUP ERROR AS "NEW USER"
        // ====================================================

        if (membershipError) {
          console.error(
            'Workspace lookup failed:',
            membershipError,
          );

          setMessage(
            'Your account was verified, but your workspace could not be loaded.',
          );

          /*
           * Safer to send them to login than business setup.
           *
           * An existing Kanwave Admin must never be asked
           * to create another tenant merely because a
           * membership query failed.
           */
          await supabase.auth.signOut();

          navigate(
            '/login',
            {
              replace: true,
            },
          );

          return;
        }

        // ====================================================
        // 4. EXISTING WORKSPACE MEMBER
        // ====================================================

        if (
          Array.isArray(memberships) &&
          memberships.length > 0
        ) {
          navigate(
            '/dashboard',
            {
              replace: true,
            },
          );

          return;
        }

        // ====================================================
        // 5. GENUINELY NEW USER
        // ====================================================

        navigate(
          '/onboarding/business',
          {
            replace: true,
          },
        );
      } catch (error) {
        console.error(
          'Authentication callback failed:',
          error,
        );

        if (!active) {
          return;
        }

        navigate(
          '/login',
          {
            replace: true,
          },
        );
      }
    }

    completeAuthentication();

    return () => {
      active = false;
    };
  }, [navigate]);

  return (
    <main className="flex min-h-screen items-center justify-center bg-slate-50 px-4">
      <div className="w-full max-w-md rounded-2xl border border-slate-200 bg-white p-8 text-center shadow-sm">
        <div className="mx-auto h-10 w-10 animate-spin rounded-full border-4 border-indigo-200 border-t-indigo-600" />

        <h1 className="mt-5 text-lg font-bold text-slate-900">
          CloudRouter
        </h1>

        <p className="mt-2 text-sm text-slate-600">
          {message}
        </p>
      </div>
    </main>
  );
}